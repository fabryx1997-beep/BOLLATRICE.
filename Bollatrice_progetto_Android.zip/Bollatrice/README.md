# La mia bollatrice — progetto Android

Progetto sorgente per Android Studio, pensato per HONOR Magic7 Pro.

## Funzioni incluse nel sorgente
- Widget nativo Home con pulsanti Inizio, Pausa, Viaggio e Fine.
- Una sola pausa giornaliera (inizio/fine); la fine giornata chiude automaticamente una pausa rimasta aperta.
- Inizio/fine viaggio e calcolo della durata in esportazione.
- Inserimento/correzione manuale per data, orari e luogo di lavoro.
- Dati conservati solo nelle preferenze private locali dell'app; nessuna autorizzazione Internet richiesta.
- Esportazione mensile CSV apribile in Excel, con intestazioni compatibili con i campi del modello fornito.

## Limiti da completare/verificare
Questo ambiente non contiene Android SDK/Gradle e non ha accesso alla rete, quindi qui non è stato possibile compilare o testare un APK installabile. Aprire il progetto in Android Studio con SDK 35 e compilare `app` per generare l'APK. Il CSV esportato è un file di scambio, non modifica direttamente il file `.xlsx` originale. La UI del widget e il comportamento vanno testati sul dispositivo prima dell'uso quotidiano.

## Creazione APK
1. Aprire Android Studio → Open → selezionare questa cartella.
2. Installare Android SDK Platform 35 quando richiesto e attendere la sincronizzazione Gradle.
3. Build → Build APK(s).
4. Aggiungere il widget dalla schermata Home: pressione prolungata sulla Home → Widget → La mia bollatrice.
